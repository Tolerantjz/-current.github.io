<?php 
	require_once '../common.php';
	$openid=$_GET["openid"];
	$nickname=$_GET["nickname"];
	$headimgurl=$_GET["headimgurl"];
	$score=$_GET["grade"];
	$act=$_GET["act"];
	
	if($act=="score"){
		$query="SELECT * FROM rank WHERE openid='{$openid}'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0){
			$row=mysql_fetch_assoc($result);
			if($row["score"]<$score){
				$query="UPDATE rank SET score='{$score}' WHERE openid='{$openid}'";
				$result=mysql_query($query);
				if(mysql_affected_rows()>0){
					echo '{"err":"0","msg":"更新成功"}';
				}else{
					echo '{"err":"1","msg":"更新失败"}';
				}
			}else{
				echo '{"err":"01","msg":"没超过分数"}';
			}
		}else{
			$query="INSERT INTO rank(id,openid,nickname,headimgurl,score) VALUES (null,'{$openid}','{$nickname}','{$headimgurl}','{$score}')";
			$result=mysql_query($query);
			if(mysql_insert_id()>0){
				echo '{"err":"0","msg":"插入成功"}';
			}else{
				echo '{"err":"1","msg":"插入失败"}';
			}
		}
	}else if($act=="rank"){
		$arr=array();
		$query="SELECT *FROM rank ORDER BY score DESC LIMIT 0,20";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0){
			while($row=mysql_fetch_assoc($result)){
				$arr[]=$row;
			}
			$str=json_encode($arr);
		}else{
			echo '{"err":"1","msg":"获取失败"}';
		}
	}
	
?>