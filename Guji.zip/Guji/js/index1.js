function isAdater() {
	var Agents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"];
	var userAgentInfo = navigator.userAgent;
	var flag = false;
	for (var i = 0; i < Agents.length; i++) {
		if (userAgentInfo.indexOf(Agents[i]) > 0) {
			flag = true;
			break;
		}
	}
	return flag;
}

function rand(min, max) {
	return parseInt(Math.random() * (max - min + 1)) + min;
}
function collide(obj1, obj2) {
	var l1 = obj1.x;
	var r1 = l1 + obj1.w;
	var t1 = obj1.y;
	var b1 = t1 + obj1.h;
	var l2 = obj2.x;
	var r2 = l2 + obj2.w;
	var t2 = obj2.y;
	var b2 = t2 + obj2.h;
	if (r1 > l2 && l1 < r2 && b1 > t2 && t1 < b2) {
		return true;
	} else {
		return false;
	}
}

var cav = document.getElementById("cav");
var over=document.getElementById("over");

if (isAdater()) {
	cav.width = document.documentElement.clientWidth;
	cav.height = document.documentElement.clientHeight;
}
var cxt = cav.getContext("2d");
var cW = cav.width;
var cH = cav.height;
var gametime = 0;
var bullets = [];
var bulletSpeed = 15;
var speed=5;
var emys=[];
var props=[];
var enemyspeed=25;
var bullettime=0;
var bombnum=0;
var grade=0;
var stop=false;
var bgImg = new Image();
bgImg.src = "img/bg.jpg";
var imgplane = new Image();
imgplane.src = "./img/plane.png";

var imgplanee = new Image();
imgplanee.src = "./img/planee.png";

var imgbullet1 = new Image();
imgbullet1.src = "./img/bullet1.png";

var imgbullet2 = new Image();
imgbullet2.src = "./img/bullet2.png";

var imgprop1 = new Image();
imgprop1.src = "./img/prop1.png";

var imgprop2 = new Image();
imgprop2.src = "./img/prop2.png";

var imgenemy1 = new Image();
imgenemy1.src = "./img/enemy1.png";

var imgenemy2 = new Image();
imgenemy2.src = "./img/enemy2.png";

var imgenemy1e = new Image();
imgenemy1e.src = "./img/enemy1e.png";

var imgenemy2e = new Image();
imgenemy2e.src = "./img/enemy2e.png";

// 新加图片对象
var imgfenshu_bg = new Image();
imgfenshu_bg.src = "./img/fenshu_bg.png";

bgobj = {
	x: 0,
	y: 0,
	w: cW,
	h: 2270,
	draw: function() {
		this.move();
		cxt.drawImage(bgImg, this.x, this.y - this.h + 1, this.w, this.h);
		cxt.drawImage(bgImg, this.x, this.y, this.w, this.h);
	},
	move: function() {
		this.y += 1;
		if (this.y >= this.h) {
			this.y = 0;
		}
	}
}

var plane = {
	bullet: 0,
	bomb:0,
	x: cW * 0.5 - 50,
	y: cH * 0.7,
	w: 100,
	h: 130,
	sx: 0,
	sy: 0,
	blood:1,
	space:0,
	left: false,
	right: false,
	top: false,
	bottom: false,
	draw: function() {
		this.move();
		cxt.drawImage(imgplane, this.sx, this.sy, this.w, this.h, this.x, this.y, this.w, this.h);
	},
	move: function() {
		if (this.x <= 0) {
			this.x = 0;
			this.left = false;
		} else if (this.x > cW - this.w) {
			this.x = cW - this.w;
			this.right = false;
		}
		if (this.y <= 0) {
			this.y = 0;
			this.top = false;
		} else if (this.y >= cH - this.h) {
			this.y = cH - this.h;
			this.bottom = false;
		}
		if (this.left && !this.right) {
			this.x -= 10;
		}
		if (!this.left && this.right) {
			this.x += 10;
		}
		if (this.top && !this.bottom) {
			this.y -= 10;
		}
		if (!this.top && this.bottom) {
			this.y += 10;
		}
		this.left = false;
		this.right = false;
		this.top = false;
		this.bottom = false;
		if(this.blood<=0){
			this.img=imgplanee;
			console.log(this.sx);
			this.space++;
			if(this.space%3==0){
				this.sx+=this.w;
				cxt.drawImage(imgplanee,this.sx,0,100,133,this.x,this.y,100,133);
			}
			if(this.sx>400){
				this.space=0;
				stop=true;
				over.style.display="block";
				$(".score2").show();
				$(".score2 #nowScore").html(grade);
			}
		}
	}
}

function Buttle() {
	this.blood = 1;
	this.w = 69;
	this.h = 69;
	this.img = imgbullet1;
	if (plane.bullet == 1) {
		this.blood = 2;
		this.w = 96;
		this.h = 96;
		this.img = imgbullet2;
	}
	this.x = plane.x + (plane.w - this.w) / 2;
	this.y = plane.y - this.h;
	this.draw = function() {
		this.move();
		cxt.drawImage(this.img, this.x, this.y, this.w, this.h);
	}
	this.move = function() {
		this.y -= 10;
	}
}

function Enemy() {
	var r=rand(0,15)
	this.r=r;
	this.speed=5;
	this.space=0;
	this.start=0;
	if(this.r<=10){
		this.img=imgenemy1;
		this.w=90;
		this.h=87;
		this.blood=2;
	}else{
		this.img=imgenemy2;
		this.w=110;
		this.h=88;
		this.blood=4;
		this.speed=speed*0.6;
	}
	this.x=rand(80,cW-this.w-80);
	this.y=rand(-this.h-10,-this.h);
	this.move=function(){
		if(this.blood>0){
			this.y+=this.speed;
			this.space++;
			if(this.space>=5){
				this.space=0
				this.start+=this.w;
				if(this.start>this.w){
					this.start=0;
				}
			}
		}
		if (this.blood <= 0) {
			if (this.space >= 0) {
				this.space = -1;
				if (this.r < 10) {
					this.w = 115;
					this.h = 95;
					this.start = 0;
					this.img = imgenemy1e;
				}else if (this.r <= 14) {
					this.w = 126;
					this.h = 95;
					this.start = 0;
					this.img = imgenemy2e;
				}	
			};
			
			if (this.start < this.w*10) {
				this.start += this.w;
			}else{
				for (var i=0,len=emys.length;i<len;i++) {
					if(this==emys[i]){
						emys[i].y=2000;
						
					}
				}
			}
		};
	};
	this.draw=function(){
		this.move();
		cxt.drawImage(this.img,this.start,0,this.w,this.h,this.x,this.y,this.w,this.h);
	};
}
function Prop(){
	var r=rand(0,1);
	this.r=r;
	this.w=120;
	this.h=83;
	this.img=imgprop1;
	if(this.r==1){
		this.w=117;
		this.h=117;
		this.img=imgprop2;
	}
	this.x=rand(0,cW-this.w);
	this.y=-this.h;
	this.move=function(){
		this.y+=speed*0.7;
	}
	this.draw=function(){
		this.move();
		cxt.drawImage(this.img,this.x,this.y,this.w,this.h);
	}
	
}
var imgarr = ["img/loading_tu.png", "img/logo.png", "img/anniu_bufu.png", "img/anniu_guanbi.png", "img/anniu_paihangbang.png", "img/anniu_paihangbang1.png", "img/anniu_pk.png", "img/anniu_zailaiyici.png", "img/anniu_zailaiyici1.png", "img/bg.jpg", "img/bullet1.png", "img/bullet2.png", "img/chahua1_bg.png", "img/chahua1_hua1.png", "img/chahua1_hua2.png", "img/chahua2_bg.png", "img/chahua2_hua1.png", "img/chahua2_hua2.png", "img/chahua2_hua3.png", "img/chahua2_hua4.png", "img/chahua3_bg.png", "img/duishou_fenshu_bg.png", "img/enemy1.png", "img/enemy1e.png", "img/enemy2.png", "img/enemy2e.png", "img/erweima.png", "img/fenshu_bg.png", "img/game_bg.png", "img/guanzhu.png", "img/guize_bg.jpg", "img/guji1.png", "img/guji2.png", "img/jiangpai1.png", "img/jiangpai2.png", "img/jiangpai3.png", "img/jiangpin.png", "img/P1.jpg", "img/paihangbang_bg.png", "img/paihangbang_biaoti.png", "img/paihangbang_paiming_lihe.png", "img/plane.png", "img/planee.png", "img/prop1.png", "img/shouye_bg.jpg", "img/shouye_biaoti.png", "img/shouye_guaiwu.png", "img/shouye_jiangpin.png", "img/shouye_kaishi.png", "img/shouye_paihangbang.png", "img/touxiang_mengban.png", "img/touxiang_mengban2.png"];
var imgobj = [];
var imgs = 0;
var jindu = 0;
for (var i = 0, len = imgarr.length; i < len; i++) {
	imgobj[i] = new Image();
	imgobj[i].src = imgarr[i];
	imgobj[i].onload = function() {
		imgs++;
		jindu = Math.floor((imgs / len) * 100) * 0.01;
		jindu = jindu.toFixed(2);
		$(".loadingTu").css("background-position", Math.floor(jindu * 6) * -233 + "px 0px");
		$(".loadContent").css("width", jindu * ($(".loadingTiao").width()) + "px");
		jindu = jindu * 100;
		jindu = Math.floor(jindu);
		$(".wenzi").text(jindu + "% loading...");
		if (imgs >= len) {
			$(".loading").fadeOut();
			$(".chahua").fadeIn();
		};
	}
};


$(".chahua").on("click",function(){
	$(".chahua").fadeOut();
	$(".home").fadeIn();
});
$(".chahua3").get(0).addEventListener("webkitAnimationEnd",function(){
	$(".chahua").fadeOut(1000);
	$(".home").fadeIn(1000);
},false);
$(".start").get(0).addEventListener("webkitAnimationEnd",function(){
	$(".monster").css({
		"-webkit-transform": "rotate(30deg) translateY(0%)",          
        "transform": "rotate(30deg) translateY(0%)",
        "opacity":"1"
	});
},false);
$(".start").get(0).addEventListener("touchstart",function(){
	$(".home").fadeOut();
	$(".rules").fadeIn();
},false);
$(".rules").get(0).addEventListener("touchstart",function(){
	$(".rules").fadeOut();
	$(".game").fadeIn();
	animate();
},false);
var touchX = 0;
var touchY = 0;
var touchendX=0;
var touchendY=0;
var isdown = false;
cav.addEventListener("touchstart", function() {
	var x = event.touches[0].pageX;
	var y = event.touches[0].pageY
	touchX = x - plane.x;
	touchY = y - plane.y;
	touchendX=x;
	touchendY=y;
	if (x > plane.x && x < plane.x + plane.w && y > plane.y && y < plane.y + plane.w) {
		isdown = true;
	}
}, false);
cav.addEventListener("touchmove", function() {
	if (!isdown) {
		return;
	}
	var x = event.touches[0].pageX - touchX;
	var y = event.touches[0].pageY - touchY;
	plane.x = x;
	plane.y = y;
	event.preventDefault();
}, false);
cav.addEventListener("touchend", function() {
	isdown = false;
}, false);
document.addEventListener("keydown", function(e) {
	switch (e.keyCode) {
		case 37:
			plane.left = true;
			plane.right = false;
			break;
		case 38:
			plane.top = true;
			plane.bottom = false;
			break;
		case 39:
			plane.left = false;
			plane.right = true;
			break;
		case 40:
			plane.top = false;
			plane.bottom = true;
			break;
	}
}, false);
document.addEventListener("keyup", function() {
	plane.left = false;
	plane.top = false;
	plane.right = false;
	plane.bottom = false;
}, false);
cav.addEventListener("touchend",function(){
	if(plane.bomb==1&&touchendX>(cW-127)&&touchendX<(cW-10)&&touchendY>(cH-127)&&touchendY<(cH-10)){
		for(var i=0;i<emys.length;i++){
			if(emys[i].blood!=0){
				emys[i].blood=0;
			}
			if(emys[i].r<=10){
				grade+=10;
			}else{
				grade+=20;
			}
		}
		bombnum--;
		if(bombnum<=0){
			plane.bomb=0;
		}
	}
},false);
$(".again").get(0).addEventListener("touchstart",function(){
	alert("b");	
	$(over).fadeOut();
	stop=false;
	again();
	
},false);
$(".ranking").get(0).addEventListener("touchstart",function(e){
	alert("a");
	$(over).fadeOut();
	$(".rank_wrap").fadeIn();
	
},false);

function main() {
	gametime++;
	if(gametime>2000){
		gametime=1;
	}
	bgobj.draw();
	plane.draw();
	//子弹与敌机的碰撞
	for (var i = 0,len = bullets.length; i < len; i++) {
		if (bullets[i].y > 0 && plane.blood > 0) {
			for (var j = 0,lenj = emys.length; j < lenj; j++) {
				if (emys[j].y < cH && emys[j].blood > 0 && collide(bullets[i],emys[j])) {
					emys[j].blood -= bullets[i].blood;
					if(emys[j].blood<=0){
						if(emys[j].r<=10){
							grade+=10;
						}else{
							grade+=20;
						}
					}
					
					bullets.splice(i,1);
					i--;
					len--;
					break;
				};
			};	
		};
	};
	
	
	//飞机与道具的碰撞
	for(var i=0,len=props.length; i<len;i++){
		if(props[i].y<cH&&plane.blood>0&&collide(props[i],plane)){
			if(props[i].r==0){
				plane.bullet=1;
			}else{
				plane.bomb=1;
				bombnum++;
			}
			props.splice(i,1);
			i--;
			len--;
		}
	}
	if(plane.bomb==1){
		cxt.drawImage(imgprop2,cW-127,cH-127,117,117);
	}
	if(plane.bullet==1){
		bullettime++;
		if(bullettime>300){
			plane.bullet=0;
			bullettime=0;
		}
	}
	
	//飞机与敌机的碰撞
	for(var i=0,len=emys.length;i<len;i++){
		if(plane.blood>0&&emys[i].blood>0&&collide(emys[i],plane)){
			emys[i].blood=0;
			plane.blood=0;
		}
	}
	
	
	//子弹的创建
	if (gametime % bulletSpeed == 0 ) {
		bullets.push(new Buttle());
		for (var i = 0,len = bullets.length; i < len; i++) {
			if (bullets[i].y < 0) {
				bullets.splice(i,1);
				i--;
				len--;
			};	
		};
		// console.log(bullets.length);
	};

	for (var i = 0,len = bullets.length; i < len; i++) {
		bullets[i].draw();
	};
	
	//怪物的创建
	if (gametime % enemyspeed == 0) {
		emys.push(new Enemy());
		for(var i=0,len=emys.length;i<len; i++){
			if(emys[i].y>cH){
				emys.splice(i,1);
				i--;
				len--;
			}
		}
	}
	
	for (var i = 0,len = emys.length; i < len; i++) {
			emys[i].draw();
		
	};
	//道具的创建
	
	
	if(gametime%500==0){
		props.push(new Prop());
		for(var i=0,len=props.length;i<len; i++){
			if(props[i].y>cH){
				props.splice(i,1);
				i--;
				len--;
			}
		}
	}
	for(var i=0; i<props.length; i++){
		props[i].draw();
		
	}
	
	
	cxt.drawImage(imgfenshu_bg, 0, 0, 168, 71, cW - 188, 10, 168, 71);
	cxt.font = '32px 黑体';
	cxt.textBaseline = "top";
	cxt.fillText(grade,cW - 105,33);
	
	
}

function animate() {
	cxt.clearRect(0, 0, cav.width, cav.height);
	main();
	var anim=window.requestAnimationFrame(animate);
	if(stop){
		window.cancelAnimationFrame(anim);
	}
}
function again(){
//	cxt.clearRect(0,0,cav.width,cav.height);
	plane.x=cW/2-50;
	plane.y=cH*0.7;
	plane.blood=1;
	plane.bullet=0;
	plane.bomb=0;
	plane.img=imgplane;
	plane.sx=0;
	grade=0;
	for(var i=0; i<emys.length;i++){
		emys[i].y=-10;
		emys[i].blood=0;
	}
	animate();
}
//function getScore(){
//	$.ajax({
//		url:"getscore.php",
//		data:{
//			"openid":openid,
//			"nickname":nickname,
//			"headimgurl":headimgurl,
//			"grade":grade
//		},
//		dataType:"json",
//		success:function(data){
//			alert(grade);
//			over.style.display="block";
//			if(data.err=="0"){
//				$(".score2").show();
//				$("#nowScore").html(grade);
//			}else if(data.err=="01"){
//				$(".score1").show();
//				$("#nowScore").html(grade);
//			}
//			
//		}
//	});
//}
