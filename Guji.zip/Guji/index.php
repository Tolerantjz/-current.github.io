<?php
	require_once "jssdk.php";
	$jssdk = new JSSDK("wxaf6b1d952815abf5", "109970d0c7d4929010df3e6c66c9b1d1");
	$signPackage = $jssdk->GetSignPackage();
?>
<?php  
	require_once '../common.php';
	$code = $_GET["code"];
	$appid="wxaf6b1d952815abf5";
  	$appsecret="109970d0c7d4929010df3e6c66c9b1d1";
	$getTokenApi="https://api.weixin.qq.com/sns/oauth2/access_token?appid={$appid}&secret={$appsecret}&code={$code}&grant_type=authorization_code";
	$str1=httpGet($getTokenApi);
	$arr1=json_decode($str1,true);
	$openid=$arr1["openid"];
	$commonToken=$arr1["access_token"];
	$getUerinfo="https://api.weixin.qq.com/sns/userinfo?access_token={$commonToken}&openid={$openid}&lang=zh_CN";
	$str2=httpGet($getUerinfo);
	$arr2=json_decode($str2,true);
	$headimgurl=$arr2["headimgurl"];
	$nickname=$arr2["nickname"];
?>

	<!DOCTYPE html>
	<html>

	<head>
		<script src="js/phone.js" type="text/javascript" charset="utf-8"></script>
		<meta charset="utf-8" />
		<title>咕叽大作战</title>
		<link rel="stylesheet" type="text/css" href="css/animate.css" />
		<link rel="stylesheet" type="text/css" href="css/index.css" />
	</head>

	<body>
		<audio controls="true" autoplay="true" loop="true" src="music/bgmusic.mp3"></audio>
		<audio loop="loop" preload="auto" id="musicbullet">
		  	<source src="./music/bullet.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musicover">
		  	<source src="./music/game_over.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musicbomb">
		  	<source src="./music/bomb.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musice1">
		  	<source src="./music/enemy1.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musice2">
		  	<source src="./music/enemy1.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musice3">
		  	<source src="./music/enemy1.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musice4">
		  	<source src="./music/enemy1.mp3" type="audio/mpeg">
		</audio>
		<audio preload="auto" id="musice5">
		  	<source src="./music/enemy1.mp3" type="audio/mpeg">
		</audio>
		<div id="wrap">
			<div class="loading">
				<div class="loadingWrap">
					<div class="loadingTu"></div>
					<div class="loadingTiao">
						<div class="loadContent"></div>
					</div>
					<div class="wenzi">0%&nbsp;&nbsp;loading......</div>
				</div>
			</div>
			<div class="chahua">
				<div class="neirong">
					<div class="chahua1 animated bounceInLeft">
						<div class="chahua1_hua1">
							<img src="img/chahua1_hua1.png" />
						</div>
						<div class="chahua1_hua2">
							<img src="img/chahua1_hua2.png" />
						</div>
					</div>
					<div class="chahua2 animated bounceInRight">
						<div class="chahua2_hua1">
							<img src="img/chahua2_hua1.png" />
						</div>
						<div class="chahua2_hua2">
							<img src="img/chahua2_hua2.png" />
						</div>
						<div class="chahua2_hua3">
							<img src="img/chahua2_hua3.png" />
						</div>
						<div class="chahua2_hua4">
							<img src="img/chahua2_hua4.png" />
						</div>
					</div>
					<div class="chahua3 animated bounceInLeft"></div>
				</div>

			</div>
			<div class="home">
				<div class="monster">
					<img src="img/shouye_guaiwu.png" alt="" />
				</div>
				<div class="logo">
					<img src="img/shouye_biaoti.png" />
				</div>

				<div class="start">
					<img src="img/shouye_kaishi.png" />
				</div>
				<div class="buttle">
					<img src="img/bullet1.png" />
				</div>
				<div id="rank">
					<img src="img/shouye_paihangbang.png" />
				</div>
				<div class="award">
					<img src="img/shouye_jiangpin.png" />
				</div>
			</div>
			<div class="rules"><img src="img/guize_bg.jpg" alt="" /></div>
			<div class="game">
				<canvas id="cav" width="640" height="780"></canvas>
			</div>
			<div id="over">
				<div class="score1">
					<div class="guji"></div>
					<div class="txt">
						<div id="note">咕叽大暴走结束了...</div>
						<p><span id="nowScore">30</span>分！</p>
					</div>
					<div class="pk"><img src="img/anniu_pk.png" /></div>
					<div class="again"><img src="img/anniu_zailaiyici1.png" /></div>
					<div class="ranking"><img src="img/anniu_paihangbang1.png" /></div>
				</div>
				<!--<div class="score2">
					<div class="guji"><img src="img/guji1.png"/></div>''
					<div class="txt">
						<div>哇噻<br>创新纪录~</div>
						<p><span id="nowScore">30</span>分！</p>
					</div>
					<div class="pk"><img src="img/anniu_pk.png"/></div>
					<div class="again"><img src="img/anniu_zailaiyici1.png"/></div>
					<div class="ranking"><img src="img/anniu_paihangbang1.png"/></div>
				</div>
				<div class="score3">
					<div class="guji"><img src="img/guji1.png"/></div>''
					<div class="txt">
						<div>哈哈，太容易啦完爆</div>
						<p><span id="nowScore">30</span>分！</p>
					</div>
					<div class="pk"><img src="img/anniu_pk.png"/></div>
					<div class="again"><img src="img/anniu_zailaiyici1.png"/></div>
					<div class="ranking"><img src="img/anniu_paihangbang1.png"/></div>
				</div>
				<div class="score4">
					<div class="guji"><img src="img/guji2.png"/></div>
					<div class="txt">
						<div>呜呜！差点就可以超过</div>
						<p><span id="nowScore">30</span>分！</p>
					</div>
					<div class="pk"><img src="img/anniu_pk.png"/></div>
					<div class="again"><img src="img/anniu_zailaiyici1.png"/></div>
					<div class="ranking"><img src="img/anniu_paihangbang1.png"/></div>
				</div>-->
			</div>
			<div class="rank_wrap">
				<div class="rank">
					<div class="title"></div>
					<div id="list">
						<div class="line">
							<div class="ranked"></div>
							<div class="headimg"><img src="img/anniu_guanbi.png" /></div>
							<div class="nick">
								<div class="nickname">梦醒时分</div>
								<div class="grade">100</div>
							</div>
							<div class="gift"></div>
						</div>
					</div>
					<div class="txt">
						排行榜成绩截止至12月26日<br>获奖详情请看下期推文
					</div>
					<div class="close"><img src="img/anniu_guanbi.png" /></div>
				</div>
			</div>
			<div class="award_wrap">
				<div class="prize">
					<div class="award_close">
						<img src="img/anniu_guanbi.png" />
					</div>
				</div>
			</div>
			<div class="focus"></div>
		</div>
	</body>
	<script src="js/jquery-1.12.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
		var openid = "<?php echo $openid; ?>";
		var headimgurl = "<?php echo $headimgurl ?>";
		var nickname = "<?php echo $nickname ?>";
	</script>
	<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
	<script type="text/javascript">
		wx.config({
			//	    debug: true,
			appId: '<?php echo $signPackage["appId"];?>',
			timestamp: '<?php echo $signPackage["timestamp"];?>',
			nonceStr: '<?php echo $signPackage["nonceStr"];?>',
			signature: '<?php echo $signPackage["signature"];?>',
			jsApiList: [
				// 所有要调用的 API 都要加到这个列表中
				"onMenuShareTimeline",
				"onMenuShareAppMessage",
				"chooseImage"
			]
		});
		wx.ready(function() {
			// 在这里调用 API
			wx.onMenuShareTimeline({
				title: "咕叽版飞机大战，挑战高分赢取大礼，还可以和朋友一比高下！", // 分享标题
				desc: '我在咕叽版飞机大战中玩了' + rand(1000, 10000) + '分,你也来玩玩,超刺激!!!',
				link: 'http://indexmm.applinzi.com/Guji/send.html', // 分享链接
				imgUrl: 'http://indexmm.applinzi.com/Guji/img/p.png', // 分享图标
				success: function() {
					// 用户确认分享后执行的回调函数
					window.location.href = "http://indexmm.applinzi.com/Guji/send.html";
				},
				cancel: function() {
					// 用户取消分享后执行的回调函数
				}
			});
			wx.onMenuShareAppMessage({
				title: "咕叽版飞机大战，挑战高分赢取大礼，还可以和朋友一比高下！", // 分享标题
				desc: '我在咕叽版飞机大战中玩了' + rand(1000, 10000) + '分,你也来玩玩,超刺激!!!',
				link: 'http://indexmm.applinzi.com/Guji/send.html', // 分享链接
				imgUrl: 'http://indexmm.applinzi.com/Guji/img/p.png', // 分享图标
				type: '', // 分享类型,music、video或link，不填默认为link
				dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
				success: function() {
					// 用户确认分享后执行的回调函数
					window.location.href = "http://indexmm.applinzi.com/Guji/send.html";
				},
				cancel: function() {
					// 用户取消分享后执行的回调函数
				}
			});
		});
	</script>
	<script src="js/index.js" type="text/javascript" charset="utf-8"></script>

	</html>